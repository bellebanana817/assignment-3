# Animal Crossing: Isabelle's Day Off ☀️(Pure CSS)

A Pen created on CodePen.io. Original URL: [https://codepen.io/acupoftee/pen/gOaoWmX](https://codepen.io/acupoftee/pen/gOaoWmX).

After a hard day's work, Isabelle basks under the sun on this glorious spring day. 

Animal Crossing is a game bringing so much merriment. Although I don't have a copy of New Horizons yet, I wanted to challenge myself by creating artwork inspired by the game! This was a fun way to practice isomorphic art with CSS. Enjoy and  stay well friends.

Timlapse: https://youtu.be/c0HTgIItRhc