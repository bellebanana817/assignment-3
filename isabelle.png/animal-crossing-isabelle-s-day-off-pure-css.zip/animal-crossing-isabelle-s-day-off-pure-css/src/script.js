// Coding Timelapse w/ resources:
// https://youtu.be/c0HTgIItRhc
// Thanks for stopping by! Stay well and safe ❤️
